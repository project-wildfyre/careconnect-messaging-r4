### HSCIC HL7v2 Documents

[HSCIC ITK HL7 V2 Message Specifications](downloads/HSCIC ITK HL7 V2 Message Specifications.pdf)

[HSCIC ITK HL7 V2 Reference Tables](downloads/HSCIC ITK HL7 V2 Reference Tables.pdf)
