### HL7v2 to FHIR Mapping

Work In Progress

Strongly advise consulting this mapping spreadsheet.
[v2-to-FHIR Map Inventory](https://docs.google.com/spreadsheets/d/1PaFYPSSq4oplTvw_4OgOn6h2Bs_CMvCAU9CqC4tPBgk)
