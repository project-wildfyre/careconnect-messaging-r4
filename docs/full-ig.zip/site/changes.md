<div xmlns="http://www.w3.org/1999/xhtml" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://hl7.org/fhir ../../input-cache/schemas-r5/fhir-single.xsd">
	<p>
    This provides a list of changes to the MyIG specification since its initial release
  </p>
  <a name="0.1.0"> </a>
	<p>
		<b>2099-01-01 v0.1.0 - My IG R1 (STU ballot 1) Ballot Candidate</b> based on FHIR R4
  </p>
  <ul>
    <li>Initial version</li>
  </ul>
</div>
