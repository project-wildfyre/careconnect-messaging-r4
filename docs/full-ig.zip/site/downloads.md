### HSCIC HL7v2 Documents

[HSCIC ITK HL7 V2 Message Specifications](downloads/HSCIC ITK HL7 V2 Message Specifications.pdf)

[HSCIC ITK HL7 V2 Reference Tables](downloads/HSCIC ITK HL7 V2 Reference Tables.pdf)

[HL7 UK Standard for Use of HL7 Version 2 in the UK](https://www.hl7.org.uk/wp-content/uploads/HL7UK_Media/Documents/Standards/HL72UKA.3-v2.pdf)